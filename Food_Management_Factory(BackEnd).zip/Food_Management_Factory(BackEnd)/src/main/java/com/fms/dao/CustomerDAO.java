package com.fms.dao;

import org.hibernate.Session;

import com.fms.entity.Customer;

import com.fms.util.HibernateUtil;

public class CustomerDAO {

	
	
	public String fetchLastAddedCustomerId() {
		Session session = HibernateUtil.getSession();
		Object custId = session.createQuery("select max(s.id) from Customer s").getSingleResult();
		return String.valueOf(custId);
	}
	
	public void saveCustomer(Customer customer)
	{
		try(Session session = HibernateUtil.getSession()) {
			if (!session.getTransaction().isActive()) {
				session.beginTransaction();
			}

			// to generate the custom id
			String cId = fetchLastAddedCustomerId();

			if (cId.contains("null")) {
				cId = "C100";
			}

			String prefix = cId.substring(0, 1); // C
			int postfix = Integer.parseInt(cId.substring(1)); // 102
			String custId = prefix + (postfix + 1); // C + (102+1) = C + 103 = U103

			customer.setId(custId);
			customer.setRole("customer");
			
			session.save(customer);
			
			session.getTransaction().commit();
			
			System.out.println("Account created successfully!!");
			
			
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public Customer getCustById(String id)
	{
		try(Session session = HibernateUtil.getSession()) {
			return session.get(Customer.class, id);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public Customer updateCustomer(String id , Customer newCust )
	{
		try(Session session = HibernateUtil.getSession()) {
			if (!session.getTransaction().isActive()) {
				session.beginTransaction();
			}
		   
			Customer exist = session.get(Customer.class, id);
			
			exist.setDob(newCust.getDob());
			exist.setName(newCust.getName());
			exist.setEmail(newCust.getEmail());
			exist.setPassword(newCust.getPassword());
			exist.setPhone(newCust.getPhone());
			session.saveOrUpdate(exist);
			session.getTransaction().commit();
			return exist;
			
			
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
}
