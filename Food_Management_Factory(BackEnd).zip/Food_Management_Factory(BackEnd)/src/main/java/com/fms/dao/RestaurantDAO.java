package com.fms.dao;

import java.util.List;

import org.hibernate.Session;

import com.fms.entity.RestOwner;
import com.fms.entity.Restaurant;
import com.fms.util.HibernateUtil;

public class RestaurantDAO {

	public String fetchLastAddedRestId() {
		Session session = HibernateUtil.getSession();
		Object reId = session.createQuery("select max(s.restId) from Restaurant s").getSingleResult();
		return String.valueOf(reId);
	}

	public void saveRestaurant(Restaurant restaurant, RestOwner restOwner) {
		try (Session session = HibernateUtil.getSession()) {
			if (!session.getTransaction().isActive()) {
				session.beginTransaction();
			}
			
			if(restOwner.getRestaurant()!=null)
			{
				System.out.println("You have already restaurant details!!");
				return;
			}

			// to generate the custom id
			String rId = fetchLastAddedRestId();

			if (rId.contains("null")) {
				rId = "R100";
			}

			String prefix = rId.substring(0, 1); // C
			int postfix = Integer.parseInt(rId.substring(1)); // 102
			String restId = prefix + (postfix + 1); // C + (102+1) = C + 103 = U103

			restaurant.setRestId(restId);

			session.save(restaurant);
			
			restOwner.setRestaurant(restaurant);
			
			session.update(restOwner);

			session.getTransaction().commit();

			System.out.println("Restaurant details saved successfully!!");
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		

	}

	public List<Restaurant> fetchRestaurantsFromLocation(String location) {
		Session session = HibernateUtil.getSession();
		List<Restaurant> restaurants = session.createQuery("select r from Restaurant r LEFT JOIN Address a ON "
				+ "r.address = a.addId where a.location = :loc", Restaurant.class)
				.setParameter("loc", location).getResultList();
		return restaurants;
	}
	
	public Restaurant getRestById(String id)
	{
		try (Session session = HibernateUtil.getSession()) {
			if (!session.getTransaction().isActive()) {
				session.beginTransaction();
			}
			
		Restaurant rest = session.get(Restaurant.class, id);
		
		return rest;
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
		
	}

	public RestOwner updateRestaurant(String id , RestOwner newRestOwner )
	{
		try(Session session = HibernateUtil.getSession()) {
			if (!session.getTransaction().isActive()) {
				session.beginTransaction();
			}
			RestOwner exist = session.get(RestOwner.class, id);
			
			exist.setName(newRestOwner.getName());
			exist.setEmail(newRestOwner.getEmail());
			exist.setPassword(newRestOwner.getPassword());
			exist.setPhone(newRestOwner.getPhone());
			session.saveOrUpdate(exist);
			session.getTransaction().commit();
			return exist;
			
			
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
}