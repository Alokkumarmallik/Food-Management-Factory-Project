package com.fms.dao;

import org.hibernate.Session;

import com.fms.entity.User;
import com.fms.util.HibernateUtil;

public class UserDAO {

	public User login(String email, String password)
	{
		try(Session session = HibernateUtil.getSession())
		{
			return session.createQuery("from User where email = :em "
					+ "and password = : p",User.class)
			.setParameter("em", email)
			.setParameter("p", password)
			.getSingleResult();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}
