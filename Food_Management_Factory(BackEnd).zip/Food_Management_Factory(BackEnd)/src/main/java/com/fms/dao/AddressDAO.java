package com.fms.dao;

import org.hibernate.Session;

import com.fms.entity.Address;
import com.fms.util.HibernateUtil;

public class AddressDAO {

	    public void saveAddress(Address address)
	    {
		try(Session session = HibernateUtil.getSession()) {
			if (!session.getTransaction().isActive()) {
				session.beginTransaction();
			}
			
			session.save(address);
			
			session.getTransaction().commit();
			
			System.out.println("Customer Address Details saved successfully!!");
			
			
		}catch (Exception e) {
			e.printStackTrace();
		}
}
	    
	    public void updateAddress(Long id, Address newAdd)
	    {
	    	try(Session session = HibernateUtil.getSession()) {
				if (!session.getTransaction().isActive()) {
					session.beginTransaction();
				}
				
				Address exist = session.get(Address.class, id);
				
				exist.setLocation(newAdd.getLocation());
				exist.setPin(newAdd.getPin());
				exist.setCountry(newAdd.getCountry());
				exist.setState(newAdd.getState());
				
				session.update(exist);
				session.getTransaction().commit();
				
			}catch (Exception e) {
				e.printStackTrace();
			}
	    }
}
