package com.fms.entity;

//com.fms.entity.User.java

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.OneToOne;
//import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Column;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Inheritance(strategy = InheritanceType.JOINED)
public class User {
	
	@Id
	@Column(length = 10)
	private String id;
	
	@Column(length=30, nullable=false)
	private String name;
	
	@Column(length=20)
	private String password;
	
	@Column(length = 10, nullable = false, unique = true)
	private String phone;
	
	@Column(length = 50, nullable = false, unique = true)
	private String email;
	
	@Column(length = 10)
	private String role;
	
	@OneToOne
	private Address address;

	public User(String name, String password, String phone, String email, String role, Address address) {
		super();
		this.name = name;
		this.password = password;
		this.phone = phone;
		this.email = email;
		this.role = role;
		this.address = address;
	}

	
	
}
