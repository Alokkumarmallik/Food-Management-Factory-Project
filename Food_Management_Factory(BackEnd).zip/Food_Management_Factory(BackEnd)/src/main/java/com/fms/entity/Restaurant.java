package com.fms.entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Restaurant {

	@Id
	@Column(length = 10)
	private String restId;
	
	@Column(length=30, nullable = false)
	private String restName;
	
	@Column(length=30, nullable = false)
	private String regNo;
	
	@Column(length=10, nullable = false, unique = true)
	private String restPhone;
	
	@OneToOne
	private Address address;
	
	@OneToMany
	@JoinColumn(name = "restId")
	private List<Food> foods;

	public Restaurant(String restName, String regNo, String restPhone, Address address) {
		super();
		this.restName = restName;
		this.regNo = regNo;
		this.restPhone = restPhone;
		this.address = address;
	}
	
	
}
