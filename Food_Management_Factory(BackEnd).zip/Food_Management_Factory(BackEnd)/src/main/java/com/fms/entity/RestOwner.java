package com.fms.entity;

import javax.persistence.Entity;
import javax.persistence.OneToOne;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class RestOwner extends User{

	@OneToOne
	private Restaurant restaurant;

	public RestOwner(String name, String password, String phone, String email, String role, Address address) {
		super(name, password, phone, email, role, address);
	}

	
	
	
}
